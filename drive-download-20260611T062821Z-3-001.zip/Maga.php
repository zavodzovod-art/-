<?php

abstract class Transport {
    protected $speed;
    
    public function __construct($speed) {
        $this->speed = $speed;
    }
    
    abstract public function move(): string;
    
    public function getSpeed() {
        return $this->speed;
    }
}

class Car extends Transport {
    public function move(): string {
        return "Автомобиль едет по дороге со скоростью {$this->speed} км/ч";
    }
}

class Bike extends Transport {
    public function move(): string {
        return "Велосипедист едет по велодорожке со скоростью {$this->speed} км/ч";
    }
}

class Plane extends Transport {
    public function move(): string {
        return "Самолёт летит в небе со скоростью {$this->speed} км/ч";
    }
}

$transports = [
    new Car(120),
    new Bike(25),
    new Plane(900)
];

foreach ($transports as $transport) {
    echo $transport->move() . "\n";
}