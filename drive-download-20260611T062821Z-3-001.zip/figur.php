<!-- <?php

abstract class Shape {
    abstract public function calculateArea(): float;
    
    abstract public function getName(): string;
}

class Circle extends Shape {
    private $radius;
    
    public function __construct($radius) {
        $this->radius = $radius;
    }
    
    public function calculateArea(): float {
        return M_PI * $this->radius * $this->radius;
    }
    
    public function getName(): string {
        return "Круг";
    }
}

class Rectangle extends Shape {
    private $width;
    private $height;
    
    public function __construct($width, $height) {
        $this->width = $width;
        $this->height = $height;
    }
    
    public function calculateArea(): float {
        return $this->width * $this->height;
    }
    
    public function getName(): string {
        return "Прямоугольник";
    }
}

class Triangle extends Shape {
    private $base;
    private $height;
    
    public function __construct($base, $height) {
        $this->base = $base;
        $this->height = $height;
    }
    
    public function calculateArea(): float {
        return 0.5 * $this->base * $this->height;
    }
    
    public function getName(): string {
        return "Треугольник";
    }
}


$shapes = [
    new Circle(5),
    new Rectangle(4, 6),
    new Triangle(3, 8)
];

foreach ($shapes as $shape) {
    echo $shape->getName() . ": площадь = " . round($shape->calculateArea(), 2) . "\n";
} -->