<?php

class BankAccount {
    private $balance;
    
    public function __construct($initialBalance = 0) {
        $this->balance = $initialBalance;
    }
    
    public function deposit($amount) {
        if ($amount > 0) {
            $this->balance += $amount;
            echo "Внесено: $amount. Баланс: {$this->balance}\n";
        } else {
            echo "Неверная сумма для внесения\n";
        }
    }
    
    public function withdraw($amount) {
        if ($amount > $this->balance) {
            echo "Недостаточно средств. Текущий баланс: {$this->balance}\n";
            return false;
        }
        $this->balance -= $amount;
        echo "Снято: $amount. Баланс: {$this->balance}\n";
        return true;
    }
    
    public function getBalance() {
        return $this->balance;
    }
}

class SavingsAccount extends BankAccount {
    private $interestRate;
    
    public function __construct($initialBalance, $interestRate) {
        parent::__construct($initialBalance);
        $this->interestRate = $interestRate;
    }
    
    public function applyInterest() {
        $interest = $this->getBalance() * $this->interestRate / 100;
        $this->deposit($interest);
        echo "Начислены проценты: $interest\n";
    }
}

class CreditAccount extends BankAccount {
    private $creditLimit;
    
    public function __construct($initialBalance, $creditLimit) {
        parent::__construct($initialBalance);
        $this->creditLimit = $creditLimit;
    }
    
    public function withdraw($amount) {
        if ($amount > ($this->getBalance() + $this->creditLimit)) {
            echo "Превышен кредитный лимит. Доступно: " . ($this->getBalance() + $this->creditLimit) . "\n";
            return false;
        }
        
        $balance = $this->getBalance() - $amount;
        // Временное изменение через reflection для приватного свойства
        $reflection = new ReflectionClass('BankAccount');
        $property = $reflection->getProperty('balance');
        $property->setAccessible(true);
        $property->setValue($this, $balance);
        
        echo "Снято: $amount. Баланс: $balance (кредитный лимит: $this->creditLimit)\n";
        return true;
    }
}

echo "=== Сберегательный счёт ===\n";
$savings = new SavingsAccount(1000, 5);
$savings->deposit(500);
$savings->applyInterest();

echo "\n=== Кредитный счёт ===\n";
$credit = new CreditAccount(500, 1000);
$credit->deposit(200);
$credit->withdraw(800);
$credit->withdraw(500);