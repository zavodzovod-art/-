<?php

abstract class Product {
    protected $price;
    
    public function __construct($price) {
        $this->price = $price;
    }
    
    public function getPrice() {
        return $this->price;
    }
    
    abstract public function getFinalPrice(): float;
}

class PhysicalProduct extends Product {
    private $deliveryCost;
    
    public function __construct($price, $deliveryCost) {
        parent::__construct($price);
        $this->deliveryCost = $deliveryCost;
    }
    
    public function getFinalPrice(): float {
        return $this->price + $this->deliveryCost;
    }
}

class DigitalProduct extends Product {
    public function getFinalPrice(): float {
        return $this->price;
    }
}

$products = [
    new PhysicalProduct(1000, 200),
    new DigitalProduct(500),
    new PhysicalProduct(3000, 300)
];

foreach ($products as $product) {
    $type = $product instanceof PhysicalProduct ? "Физический товар" : "Цифровой товар";
    echo "$type - цена: {$product->getPrice()}, итоговая цена: {$product->getFinalPrice()}\n";
}