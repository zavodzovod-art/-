<?php

$massiv = [1, 2, 3, 4, 5, 6];
$kolichestvo = 0;

foreach ($massiv as $chislo) {
    if ($chislo % 2 == 0) {
        $kolichestvo++;
    }
}

echo $kolichestvo;

?>
