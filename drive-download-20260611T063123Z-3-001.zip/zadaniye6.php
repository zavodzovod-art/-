<?php

$massiv = [1, 2, 3, 4, 5];

for ($i = count($massiv) - 1; $i >= 0; $i--) {
    echo $massiv[$i] . " ";
}

?>
