<?php

$chisla = [];

for ($i = 1; $i <= 10; $i++) {
    $chisla[] = $i;
}

foreach ($chisla as $i) {
    foreach ($chisla as $j) {
        echo $i . " * " . $j . " = " . ($i * $j) . "\n";
    }
    echo "\n";
}

?>
