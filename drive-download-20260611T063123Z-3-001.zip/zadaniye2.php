<?php

$massiv = [3, 7, 2, 9, 5];
$maximum = $massiv[0];

for ($i = 1; $i < count($massiv); $i++) {
    if ($massiv[$i] > $maximum) {
        $maximum = $massiv[$i];
    }
}

echo $maximum;

?>
