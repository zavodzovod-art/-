<?php

$massiv = [10, 20, 30, 40, 50];
$x = 30;

for ($i = 0; $i < count($massiv); $i++) {
    if ($massiv[$i] == $x) {
        echo "Найдено, индекс: " . $i;
    }
}

?>
