<?php

$massiv = [10, 20, 30, 40, 50];
$summa = 0;

foreach ($massiv as $chislo) {
    $summa += $chislo;
}

$srednee = $summa / count($massiv);
echo $srednee;

?>
