<?php

$massiv = [3, -5, 7, -2, 8];

for ($i = 0; $i < count($massiv); $i++) {
    if ($massiv[$i] < 0) {
        $massiv[$i] = 0;
    }
}

print_r($massiv);

?>
