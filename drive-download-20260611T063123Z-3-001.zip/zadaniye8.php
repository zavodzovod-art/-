<?php

$massiv = [1, 5, 3, 8, 2, 9];
$summa = 0;

foreach ($massiv as $chislo) {
    $summa += $chislo;
}

$srednee = $summa / count($massiv);
$kolichestvo = 0;

foreach ($massiv as $chislo) {
    if ($chislo > $srednee) {
        $kolichestvo++;
    }
}

echo $kolichestvo;

?>
