<?php

$massiv = [3, 7, 2, 9, 5];
$summa = 0;

foreach ($massiv as $chislo) {
    $summa += $chislo;
}

echo $summa;

?>
