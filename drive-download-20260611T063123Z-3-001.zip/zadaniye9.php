<?php

$massiv = ["кот", "собака", "лиса", "медведь", "ёж", "слон"];

foreach ($massiv as $stroka) {
    if (strlen($stroka) > 5) {
        echo $stroka . "\n";
    }
}

?>
